package ir.omid.calculator;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private static final int REQ_WEB_PERMISSIONS = 4101;
    private static final int REQ_CALL_PHONE = 4102;
    private String pendingPhoneNumber;
    private WebView webView;
    private PermissionRequest pendingWebRequest;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setGeolocationEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean camera = false, mic = false;
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) camera = true;
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) mic = true;
                    }
                    boolean needCamera = camera && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED;
                    boolean needMic = mic && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED;
                    if (needCamera || needMic) {
                        pendingWebRequest = request;
                        java.util.ArrayList<String> perms = new java.util.ArrayList<>();
                        if (needCamera) perms.add(Manifest.permission.CAMERA);
                        if (needMic) perms.add(Manifest.permission.RECORD_AUDIO);
                        requestPermissions(perms.toArray(new String[0]), REQ_WEB_PERMISSIONS);
                    } else request.grant(request.getResources());
                });
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoOrigin = origin; pendingGeoCallback = callback;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_WEB_PERMISSIONS);
                }
            }
        });
        webView.addJavascriptInterface(new PhoneBridge(), "OmidPhone");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }


    public class PhoneBridge {
        @JavascriptInterface public void makeCall(String number) {
            runOnUiThread(() -> {
                String clean = number == null ? "" : number.replaceAll("[^+0-9*#]", "");
                if (clean.isEmpty()) { Toast.makeText(MainActivity.this, "شماره تماس را وارد کنید", Toast.LENGTH_SHORT).show(); return; }
                pendingPhoneNumber = clean;
                if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, REQ_CALL_PHONE);
                } else placeCall(clean);
            });
        }
    }
    private void placeCall(String number) {
        try { startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number))); }
        catch (SecurityException e) { Toast.makeText(this, "مجوز تماس داده نشد", Toast.LENGTH_LONG).show(); }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CALL_PHONE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && pendingPhoneNumber != null) placeCall(pendingPhoneNumber);
            else Toast.makeText(this, "مجوز تماس داده نشد", Toast.LENGTH_LONG).show();
            pendingPhoneNumber = null; return;
        }
        if (requestCode != REQ_WEB_PERMISSIONS) return;
        boolean allGranted = grantResults.length > 0;
        for (int result : grantResults) if (result != PackageManager.PERMISSION_GRANTED) allGranted = false;
        if (pendingWebRequest != null) {
            if (allGranted) pendingWebRequest.grant(pendingWebRequest.getResources()); else pendingWebRequest.deny();
            pendingWebRequest = null;
        }
        if (pendingGeoCallback != null) {
            boolean locationGranted = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
            pendingGeoCallback.invoke(pendingGeoOrigin, locationGranted, false);
            pendingGeoCallback = null; pendingGeoOrigin = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
